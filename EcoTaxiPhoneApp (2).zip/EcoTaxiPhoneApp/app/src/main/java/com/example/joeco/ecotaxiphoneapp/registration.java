package com.example.joeco.ecotaxiphoneapp;

import android.content.Intent;
import android.os.Bundle;
import android.os.Parcelable;
import android.support.annotation.NonNull;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;


public class registration extends AppCompatActivity {
    private static final String TAG = "MyActivity";
    private static final String PREFS_NAME = "prefName";


    EditText editTextName,editTextPass,editTextPhoneNumber,editTextEmail,editTextAddress,editTextDOB;
    FirebaseAuth mAuth;
    Button continueButton, socialButton;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_registration);
        editTextName = (EditText) findViewById(R.id.editTextName);
        editTextPhoneNumber = (EditText) findViewById(R.id.editTextPhoneNumber);
        editTextPass = (EditText) findViewById(R.id.editTextPassword);
        editTextEmail = (EditText) findViewById(R.id.editTextEmail);
        editTextAddress = (EditText) findViewById(R.id.editTextAddress);
        editTextDOB = (EditText) findViewById(R.id.editTextDOB);


        continueButton = (Button) findViewById(R.id.continueButton);
        mAuth = FirebaseAuth.getInstance();


        continueButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Log.d(TAG, "continue pressed ");


                String name = editTextName.getText().toString();
                String pnum = editTextPhoneNumber.getText().toString();
                String email = editTextEmail.getText().toString();
                String address = editTextAddress.getText().toString();
                String password = editTextPass.getText().toString();
                String dob = editTextDOB.getText().toString();



                createUser(email,password);
                sendMessage(name, pnum, email, address, password, dob);
                }
        });
    }

    public void createUser(String email, String password){

        mAuth.createUserWithEmailAndPassword(email, password)
                .addOnCompleteListener(registration.this,new OnCompleteListener<AuthResult>() {
                    @Override
                    public void onComplete(@NonNull Task<AuthResult> task) {
                        if (task.isSuccessful()) {
                            toastMessage("User added");
                        }else{
                            Log.d("FirebaseAuth","onComplete" + task.getException().getMessage());
                            toastMessage("Somethings gone wrong...");
                        }
                    }
                });
    }

    //This is for the continue Button
    public void sendMessage(String name,String pnum, String email,String address, String password,String dob) {
        //creates an intent and bundles it
        Intent intent = new Intent(registration.this, Registration_CardDetails.class);
        intent.putExtra("Name",name);
        intent.putExtra("pnum",pnum);
        intent.putExtra("email",email);
        intent.putExtra("address",address);
        intent.putExtra("password",password);
        intent.putExtra("dob",dob);
        startActivity(intent);
    }

    @Override
    public void onStart() {
        super.onStart();
    }

    @Override
    public void onStop(){
        super.onStop();
    }

    private void toastMessage(String message){
        Toast.makeText(this,message,Toast.LENGTH_SHORT).show();
    }

}