package com.example.joeco.ecotaxiphoneapp;

import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import static com.example.joeco.ecotaxiphoneapp.Validation.validateCreditCardNumber;

public class Registration_CardDetails extends AppCompatActivity {
    private static final String TAG = "MyActivity";

    EditText editTextCardHolder, editTextCardNumber, editTextExpiry, editTextCSV;

    private String userId;

    Button CardRegister;
    private DatabaseReference mDatabase;
    private int ID = 1;

    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_registration__card_details);

        editTextCardHolder = findViewById(R.id.editTextCardHolder);
        editTextCardNumber = findViewById(R.id.editTextCardNumber);
        editTextExpiry = findViewById(R.id.editTextExpiry);
        editTextCSV = findViewById(R.id.editTextCSV);




        CardRegister = findViewById(R.id.CardRegister);


        final String name = getIntent().getExtras().getString("Name");
        final String pnum = getIntent().getExtras().getString("pnum");
        final String email = getIntent().getExtras().getString("email");
        final String address = getIntent().getExtras().getString("address");
        final String password = getIntent().getExtras().getString("password");
        final String dob = getIntent().getExtras().getString("dob");


        CardRegister.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                //Validate ID onCreate
                String s  = "User" ;
                mDatabase = FirebaseDatabase.getInstance().getReference(s);


                String creditCardName = editTextCardHolder.getText().toString();
                String creditCardNum = editTextCardNumber.getText().toString();
                String Exp = editTextExpiry.getText().toString();
                String CSV = editTextCSV.getText().toString();


                        //*************THIS IS WHERE YOU STOPPED***********
                        Customer cust = new Customer();
                        cust.setName(name);
                        cust.setPhoneNum(pnum);
                        cust.setEmail(email);
                        cust.setCardName(creditCardName);
                        cust.setVisaNum(creditCardNum);
                        cust.setAddress(address);
                        cust.setPassword(password);
                        cust.setDob(dob);
                        cust.setExpire(Exp);
                        cust.setCsv(CSV);


                        userId = mDatabase.push().getKey();
                        mDatabase.child(userId).setValue(cust);


            }


        });
    }

            @Override
            protected void onStart() {
                super.onStart();
                Toast.makeText(getApplicationContext(), "onStart called", Toast.LENGTH_LONG).show();
            }


            @Override
            protected void onResume() {
                super.onResume();
                Toast.makeText(getApplicationContext(), "onResumed called", Toast.LENGTH_LONG).show();
            }

            @Override
            protected void onPause() {

                super.onPause();
                Toast.makeText(getApplicationContext(), "onPause called", Toast.LENGTH_LONG).show();
            }

            private void toastMessage(String message) {
                Toast.makeText(this, message, Toast.LENGTH_SHORT).show();
            }

        }